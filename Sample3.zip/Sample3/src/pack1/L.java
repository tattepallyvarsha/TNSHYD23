package pack1; //protected
import pack.*;
public class L extends K {
 public static void main(String[] args) {
	L l1=new L();
	l1.display();
}
}
