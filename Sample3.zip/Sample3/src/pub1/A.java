package pub1; //public

public class A {
 public void display() {
	 System.out.println("TNS SESSIONS");
 }
}
