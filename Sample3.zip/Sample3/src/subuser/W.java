package subuser;

public class W {
 public void msg(){
	System.out.println("Hello W");
}
}
