package pub2; //public
import pub1.*;
public class B {
 public static void main(String[] args) {
	A obj=new A();
	obj.display();
}
}
