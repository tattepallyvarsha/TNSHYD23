package p2; //default
import p1.*;

class H {
	public static void main(String[] args) {
		G g1=new G();
		g1.display();
	}

}
