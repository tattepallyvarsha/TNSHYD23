package com.day4;

public class A {
	int b=15;
	int display(){
		return 10;
	}
	static int c=20;
	static void display1(){
		System.out.println(10);
	}
}

