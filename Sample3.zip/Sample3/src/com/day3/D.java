package com.day3;

public class D {
      int b=10;
      int display(){
    	return 10;  
      }
      static int c=5;
      static void display1(){
    	   System.out.println(10);
    	  }
      public static void main(String[] args) {
		int a=20;
		System.out.println(a);
		D d1=new D();
		System.out.println(d1.b);
		d1.display();
		System.out.println(D.c);
		D.display1();
		
	}
}
