package com.day5; //private

class F {
	private void display()
	{
	 System.out.println("TNS sessions");
	}
  public static void main(String[] args) {
	F f1=new F();
	f1.display();
}
}
