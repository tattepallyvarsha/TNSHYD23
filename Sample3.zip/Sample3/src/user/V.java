package user;

public class V {
	 public void msg(){
			System.out.println("Hello V");
		}
}
