package user;

public class U {
 public static void main(String[] args) {
	System.out.println("Hello U");
}
}
