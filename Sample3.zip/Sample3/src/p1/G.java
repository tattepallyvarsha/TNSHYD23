package p1; //default

class G {
	void display() {
		System.out.println("TNS Session");
	}

}
