package p; //default without error

public class J {
  public static void main(String[] args) {
	I i1=new I();
	i1.display();
	}
}
