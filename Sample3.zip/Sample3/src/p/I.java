package p; //default without error
 class I {
	void display() {
		System.out.println("hello frnds");
	}
}
