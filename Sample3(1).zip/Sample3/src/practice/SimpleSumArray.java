package practice;

public class SimpleSumArray {
public static void main(String[] args) {
	int[] array = {2, 4, 6, 8, 10}; 
	int sum = 0; for (int num : array) { sum += num; 
	}
	System.out.println("Sum of elements in the array: " + sum); 
	    } 

}

