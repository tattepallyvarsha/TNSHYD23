package practice;
import java.util.Scanner;
public class StringConcatenation {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("Enter first string:");
	String str1=scanner.nextLine();
	System.out.println("Enter second string:");
	String str2=scanner.nextLine();
	String concatenatedString=str1+str2;
	System.out.println("the concatenated string is:"+concatenatedString);
	scanner.close();
}
}
