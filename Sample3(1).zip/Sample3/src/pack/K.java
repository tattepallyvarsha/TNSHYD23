package pack; //protected

public class K {
 protected void display() {
	 System.out.println("TNS Sessions");
 }
}
