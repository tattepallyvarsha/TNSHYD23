package user;

public class U {
 public void msg() {
	System.out.println("Hello U");
}
}
