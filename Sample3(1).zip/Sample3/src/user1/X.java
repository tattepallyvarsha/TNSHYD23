package user1;
import user.*;
import subuser.*;
public class X {
 public static void main(String[] args) {
	U u1=new U();
	V v1=new V();
	W w1=new W();
	u1.msg();
	v1.msg();
	w1.msg();
}
}
