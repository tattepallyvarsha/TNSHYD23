package com.encapsulaion2;

public class MainEmp {
	public static void main(String[] args) {
		Emp e1=new Emp();
		e1.id=43;
		System.out.println(e1.id);
	}
}
