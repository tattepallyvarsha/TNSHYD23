package com.encapsulaion2;

public class Emp {
	private String name;
	 private String salary;
	 private String age;
	 public int id;
	}

