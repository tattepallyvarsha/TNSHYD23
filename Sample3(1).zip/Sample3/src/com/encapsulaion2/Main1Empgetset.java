package com.encapsulaion2;

public class Main1Empgetset {
	public static void main(String[] args) {
		Emp1getset e1= new Emp1getset();
		e1.setId(43);
		System.out.println(e1.getId());
		Emp1getset e2= new Emp1getset();
		e2.setName("varsha");
		System.out.println(e2.getName());
	    Emp1getset e3= new Emp1getset();
		e3.setSalary(25000);
		System.out.println(e3.getSalary());
		Emp1getset e4= new Emp1getset();
		e4.setAge(24);
		System.out.println(e4.getAge());
	}
}
