package com.encapsulaion2;

public class Main2getsetAddfunctionality {
	public static void main(String[] args) {
		Emp2getsetAddfunctionality Emp=new Emp2getsetAddfunctionality();
		Emp.setName ("varsha");
		Emp.setSalary (25000);
		Emp.setAge (23);
		Emp.setId (43);
		System.out.println(Emp.details());
	}
}
