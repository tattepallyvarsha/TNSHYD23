package com.day5; //private without error
class MyClass {
     private void display() {
    	 System.out.println("hello people");
    	 }
     
}

