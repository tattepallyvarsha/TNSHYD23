package com.day5; //private

 class E {
	private static void main(String[] args) {
		MyClass obj= new MyClass();
		obj.display();
	}

}
