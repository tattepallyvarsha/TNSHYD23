package com.encapsulation1;

public class Main1Studentgetset {
 public static void main(String[] args) {
	Student1getset s2= new Student1getset();
	s2.setId(32);
	System.out.println(s2.getId());
	Student1getset s3= new Student1getset();
	s3.setName("varsha");
	System.out.println(s3.getName());
	Student1getset s4= new Student1getset();
	s4.setDepartment("ECE");
	System.out.println(s4.getDepartment());
	Student1getset s5= new Student1getset();
	s5.setAddress("Hyderabad");
	System.out.println(s5.getAddress());
	

}
 
}
