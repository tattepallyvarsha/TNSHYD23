package com.encapsulation1;

public class MainStudent {
 public static void main(String[] args) {
	Student s1=new Student();
	s1.id=32;
	System.out.println(s1.id);
}
}
