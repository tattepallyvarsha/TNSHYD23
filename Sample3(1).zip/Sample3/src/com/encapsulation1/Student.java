package com.encapsulation1;

public class Student {
 private String name;
 private String department;
 private String address;
 public int id;
}

