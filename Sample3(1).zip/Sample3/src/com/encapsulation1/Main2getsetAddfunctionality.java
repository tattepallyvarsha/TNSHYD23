package com.encapsulation1;

public class Main2getsetAddfunctionality {
	public static void main(String[] args) {
		Student2getsetAddfunctionality Student=new Student2getsetAddfunctionality();
		Student.setName ("varsha");
		Student.setAddress ("Hyderabad");
		Student.setDepartment ("ECE");
		Student.setId (32);
		
		System.out.println(Student.run ());
	}
}
