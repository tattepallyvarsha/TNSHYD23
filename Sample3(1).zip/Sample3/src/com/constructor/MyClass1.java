package com.constructor;
//constructor overloading
public class MyClass1 {
int num1;
double num2;
//default constructor
public MyClass1() {
	System.out.println("Default constructor called");
	num1=1;
	num2=1.5;
}
//parameterized constructor 1
public MyClass1(int x) {
	System.out.println("parameterized Constructor 1 called");
	num1=x;
}
//parameterized constructor 2
public MyClass1(int x, double z) {
	System.out.println("parameterized Constructor 2 called");
	num1=x;
	num2=z;
}
 void displayData() {
	 System.out.println("Num1:"+num1+"\nNum2:"+num2);
}
 public static void main(String[] args) {
	MyClass1 obj1 = new MyClass1(); //default constructor called
    obj1.displayData();	
    MyClass1 obj2 = new MyClass1(); //parameterized constructor 1 called
    obj2.displayData();	
    MyClass1 obj3 = new MyClass1(); //parameterized constructor 2 called
    obj3.displayData();	
}
}
