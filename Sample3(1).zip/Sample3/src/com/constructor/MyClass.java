package com.constructor;
//parameterized constructor
public class MyClass {
	int number;
	public MyClass(int x) {
		System.out.println("Constructor Called");
		number=x;
	}
	public static void main(String[] args) {
		MyClass obj=new MyClass(4); //parameterized constructor called
		System.out.println("Number value is:"+obj.number);
	}
}
