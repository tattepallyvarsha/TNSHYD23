package com.constructor;

public class DefaultConstructor {
int number;
public DefaultConstructor() {
	System.out.println("Constructor Called");
	number=5;
}
public static void main(String[] args) {
	DefaultConstructor obj=new DefaultConstructor(); //constructor called
	System.out.println("Number value is:"+obj.number);
}
}
