package com.polymorphism;

public class Mainparent {
	    public static void main(String[] args)
	    {
	        Parent obj1 = new Parent();
	        obj1.show();
	        Parent obj2 = new Child();
	        obj2.show();
	    }
	}

