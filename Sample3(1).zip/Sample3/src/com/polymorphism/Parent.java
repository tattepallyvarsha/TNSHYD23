package com.polymorphism;

public class Parent {

	void show() { System.out.println("Parent's show()"); }
}
// Inherited class
class Child extends Parent
{
    void show() { System.out.println("Child's show()"); }
}


