package com.inheritance;

public class Bh extends Ah{
	   public void methodBh()
	   {
	     System.out.println("Sub class Method Bh");
	   }

}
