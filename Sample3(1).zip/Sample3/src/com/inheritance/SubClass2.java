package com.inheritance;
//multi level
public class SubClass2 extends SubClass1
	{
	   public void methodC()
	   {
	     System.out.println("SubClass2");
	   }
	   public static void main(String args[])
	   {
	     SubClass2 obj = new SubClass2();
	     obj.methodA(); //calling super class method
	     obj.methodB(); //calling subclass 1 method
	     obj.methodC(); //calling own method
	  }
	}

