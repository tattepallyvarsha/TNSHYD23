package com.inheritance;
//single level
public class A {
	public void methodA()
	   {
	     System.out.println("Base class method");
	   }
	}


