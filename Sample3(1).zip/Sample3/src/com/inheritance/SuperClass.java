package com.inheritance;
//multi level
public class SuperClass {
	public void methodA()
	   {
	     System.out.println("SuperClass");
	   }
	}
	