package com.inheritance;

public class Ah {
	public void methodAh()
	   {
	     System.out.println("Super class methodAh");
	   }
	}


