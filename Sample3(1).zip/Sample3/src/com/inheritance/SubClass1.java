package com.inheritance;
//multi level
public class SubClass1 extends SuperClass{
	   public void methodB()
	   {
	     System.out.println("SubClass1 ");
	   }
	}




