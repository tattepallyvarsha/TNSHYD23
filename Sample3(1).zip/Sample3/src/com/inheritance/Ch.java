package com.inheritance;

public class Ch extends Ah {
	public void methodCh()
	   {
	     System.out.println("Sub class Method Ch");
	   }
	   public static void main(String args[])
	   {
	     Ah obj1 = new Ah();
	     Bh obj2 = new Bh();
	     Ch obj3 = new Ch();
	     obj1.methodAh(); //calling super class method
	     obj2.methodBh(); //calling A method from subclass object
	     obj3.methodCh(); //calling A method from subclass object
	  }
	}

